async function listarMinhas() {
  const r = await chamar('/api/minhas');
  $('#grade').innerHTML = (r.fotos || []).map((f) => `
    <article class="item">
      <div class="moldura"><img src="${f.arquivo}" alt="${f.titulo}"></div>
      <div class="rodape-item">
        <span>${f.titulo}</span>
        <button class="lixeira" data-id="${f.id}" title="Excluir publicação">
          <svg viewBox="0 0 24 24"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
        </button>
      </div>
    </article>`).join('');
}

function limparAvisos() {
  $('#avisoTitulo').textContent = '';
  $('#avisoLugar').textContent = '';
  $('#avisoArquivo').textContent = '';
}

(async () => {
  await iniciarTopo();
  if (!sessao || sessao.perfil !== 'fotografo') {
    location.href = 'index.html';
    return;
  }

  $('#btnEscolher').onclick = () => $('#campoArquivo').click();
  $('#campoArquivo').onchange = () => {
    const a = $('#campoArquivo').files[0];
    $('#nomeArquivo').textContent = a ? a.name : 'Nenhum arquivo escolhido';
  };

  $('#btnCadastrar').onclick = async () => {
    limparAvisos();
    const dados = new FormData();
    dados.append('titulo', $('#campoTitulo').value);
    dados.append('lugar', $('#campoLugar').value);
    const arquivo = $('#campoArquivo').files[0];
    if (arquivo) dados.append('arquivo', arquivo);
    const r = await chamar('/api/publicar', dados);
    if (r.erros) {
      $('#avisoTitulo').textContent = r.erros.titulo || '';
      $('#avisoLugar').textContent = r.erros.lugar || '';
      $('#avisoArquivo').textContent = r.erros.arquivo || '';
      return;
    }
    $('#campoTitulo').value = '';
    $('#campoLugar').value = '';
    $('#campoArquivo').value = '';
    $('#nomeArquivo').textContent = 'Nenhum arquivo escolhido';
    listarMinhas();
  };

  $('#grade').onclick = async (e) => {
    const botao = e.target.closest('.lixeira');
    if (!botao) return;
    await chamar('/api/excluir', { id: Number(botao.dataset.id) });
    listarMinhas();
  };

  listarMinhas();
})();
