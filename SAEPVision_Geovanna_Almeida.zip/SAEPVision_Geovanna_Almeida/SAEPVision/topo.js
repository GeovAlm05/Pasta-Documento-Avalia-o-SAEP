const $ = (s) => document.querySelector(s);
let sessao = null;

async function chamar(url, corpo) {
  const opcoes = { method: 'POST' };
  if (corpo instanceof FormData) {
    opcoes.body = corpo;
  } else if (corpo) {
    opcoes.headers = { 'Content-Type': 'application/json' };
    opcoes.body = JSON.stringify(corpo);
  }
  const resp = await fetch(url, opcoes);
  return resp.json();
}

function pintarTopo() {
  const avatar = $('#avatar');
  avatar.onerror = function () { this.onerror = null; this.src = 'img/avatar.svg'; };
  if (sessao) {
    $('#handle').textContent = '@' + (sessao.usuario || sessao.handle || 'SAEPVision');
    $('#avatar').src = sessao.foto || sessao.avatar || 'img/avatar.svg';
    $('#btnAcesso').textContent = 'Logout';
    $('#verPerfil').disabled = (sessao.tipo || sessao.perfil) !== 'fotografo';
  } else {
    $('#handle').textContent = '@SAEPVision';
    $('#avatar').src = 'img/avatar.svg';
    $('#btnAcesso').textContent = 'Login';
    $('#verPerfil').disabled = false;
  }
}

function abrirLogin() {
  $('#cortina').classList.add('aberta');
}

function fecharLogin() {
  $('#cortina').classList.remove('aberta');
  $('#avisoEmail').textContent = '';
  $('#avisoSenha').textContent = '';
  $('#avisoLogin').textContent = '';
}

async function abrirLateral() {
  const r = await chamar('/api/perfil');
  if (r.erro) return;
  $('#qtdLikes').textContent = r.likes + ' Likes';
  $('#qtdPubs').textContent = r.pubs + ' Publicações';
  document.body.classList.add('com-lateral');
}

async function entrar() {
  const email = $('#campoEmail').value.trim();
  const senha = $('#campoSenha').value;
  let valido = true;
  $('#avisoEmail').textContent = '';
  $('#avisoSenha').textContent = '';
  $('#avisoLogin').textContent = '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    $('#avisoEmail').textContent = 'E-mail inválido ou vazio';
    valido = false;
  }
  if (senha === '') {
    $('#avisoSenha').textContent = 'A senha é obrigatória e não pode estar vazia';
    valido = false;
  }
  if (!valido) return;
  const r = await chamar('/api/login', { email, senha });
  if (r.erro) {
    $('#avisoLogin').textContent = r.erro;
    return;
  }
  fecharLogin();
  sessao = (await chamar('/api/sessao')).usuario;
  pintarTopo();
  if (window.aposLogin) window.aposLogin();
}

async function iniciarTopo() {
  sessao = (await chamar('/api/sessao')).usuario;
  pintarTopo();
  $('#btnAcesso').onclick = async () => {
    if (sessao) {
      await chamar('/api/logout');
      location.href = 'index.html';
    } else {
      abrirLogin();
    }
  };
  $('#verPerfil').onclick = () => (sessao ? abrirLateral() : abrirLogin());
  $('#fechaLateral').onclick = () => document.body.classList.remove('com-lateral');
  $('#fechaLogin').onclick = fecharLogin;
  $('#btnCancelar').onclick = fecharLogin;
  $('#btnEntrar').onclick = entrar;
}
