let termo = '';

function montarCartao(f) {
  return `
    <article class="item">
      <div class="moldura">
        <img src="${f.arquivo}" alt="${f.titulo}">
        <div class="dica">Foto tirada por: @${f.handle}<br>Local: ${f.lugar}</div>
      </div>
      <div class="rodape-item">
        <span>${f.titulo}</span>
        <button class="btn-like" data-id="${f.id}">
          <i class="icone-coracao ${Number(f.meu) ? 'on' : ''}"></i><b>${f.total}</b>
        </button>
      </div>
    </article>`;
}

async function carregar() {
  const r = await chamar('/api/fotos', { busca: termo });
  if (r.erro) {
    $('#avisoBusca').textContent = r.erro;
    termo = '';
    return;
  }
  $('#avisoBusca').textContent = '';
  $('#grade').innerHTML = r.fotos.map(montarCartao).join('');
}

function pesquisar() {
  const texto = $('#campoBusca').value.trim();
  if (texto !== '' && !/^@?[a-zA-Z0-9_]+$/.test(texto)) {
    $('#avisoBusca').textContent = 'Formato inválido. Exemplo: fotografo1';
    return;
  }
  termo = texto;
  carregar();
}

window.aposLogin = carregar;

(async () => {
  await iniciarTopo();

  $('#grade').onclick = async (e) => {
    const botao = e.target.closest('.btn-like');
    if (!botao) return;
    if (!sessao) return abrirLogin();
    await chamar('/api/curtir', { id: Number(botao.dataset.id) });
    carregar();
  };

  $('#campoBusca').onclick = () => {
    if (!sessao) {
      $('#campoBusca').blur();
      abrirLogin();
    }
  };
  $('#campoBusca').onkeydown = (e) => {
    if (e.key === 'Enter' && sessao) pesquisar();
  };
  $('#btnLupa').onclick = () => (sessao ? pesquisar() : abrirLogin());

  carregar();
  setInterval(carregar, 3000);
})();
