require('dotenv').config();
const express = require('express');
const mysql = require('mysql2/promise');
const session = require('express-session');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const app = express();
const DB = process.env.DB_NAME || 'saepvision_geovanna';
const pool = mysql.createPool({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:DB,waitForConnections:true,connectionLimit:5});
app.use(express.json());app.use(express.urlencoded({extended:true}));
app.use(session({secret:process.env.SESSION_SECRET||'saepvision-local-dev-altere-esta-chave',resave:false,saveUninitialized:false,cookie:{httpOnly:true,sameSite:'lax'}}));
const uploadDir=path.join(__dirname,'uploads');fs.mkdirSync(uploadDir,{recursive:true});
const upload=multer({storage:multer.diskStorage({destination:uploadDir,filename:(req,file,cb)=>cb(null,crypto.randomBytes(12).toString('hex')+path.extname(file.originalname).toLowerCase())}),limits:{fileSize:10*1024*1024},fileFilter:(req,file,cb)=>cb(null,['image/jpeg','image/png','image/gif','image/webp'].includes(file.mimetype))});
const T={u:'usuario',uid:'id_usuario',handle:'handle',type:'perfil',avatar:'avatar',p:'publicacao',pid:'id_publicacao',owner:'id_usuario',place:'local_foto',image:'arquivo',likes:'curtida',likeOwner:'id_usuario',likePost:'id_publicacao'};
async function q(sql,params=[]){const [rows]=await pool.execute(sql,params);return rows;}
function respond(res,data){res.json(data)}
function auth(req,res,photographer=false){const u=req.session.user;if(!u){respond(res,{erro:'Faça login'});return null;}if(photographer&&u.tipo!=='fotografo'){respond(res,{erro:'Apenas fotógrafos'});return null;}return u;}
async function run(action,req,res){const b=req.body||{};const u=req.session.user;
 if(action==='sessao')return respond(res,{usuario:u ? {...u,handle:u.usuario,avatar:u.foto,perfil:u.tipo} : null});
 if(action==='login'){const users=await q(`SELECT ${T.uid} id,nome,${T.handle} usuario,${T.type} tipo,${T.avatar} foto FROM ${T.u} WHERE email=? AND senha=?`,[String(b.email||'').trim(),String(b.senha||'')]);if(!users.length)return respond(res,{erro:'Usuário não encontrado ou senha incorreta'});req.session.user=users[0];return respond(res,{ok:true});}
 if(action==='logout'){return req.session.destroy(()=>respond(res,{ok:true}));}
 if(action==='fotos'){let filter=String(b.fotografo??b.busca??'').trim().replace(/^@/,'');let where='',args=[u?.id||0];if(filter){const found=await q(`SELECT ${T.uid} FROM ${T.u} WHERE ${T.handle}=? AND ${T.type}='fotografo'`,[filter]);if(!found.length)return respond(res,{erro:'Fotógrafo não encontrado'});where=` WHERE u.${T.handle}=?`;args.push(filter);}const rows=await q(`SELECT p.${T.pid} id,p.titulo,p.${T.place} lugar,p.${T.image} arquivo,u.${T.handle} handle,(SELECT COUNT(*) FROM ${T.likes} c WHERE c.${T.likePost}=p.${T.pid}) total,(SELECT COUNT(*) FROM ${T.likes} c WHERE c.${T.likePost}=p.${T.pid} AND c.${T.likeOwner}=?) meu FROM ${T.p} p JOIN ${T.u} u ON u.${T.uid}=p.${T.owner}${where} ORDER BY p.${T.pid} DESC`,args);return respond(res,{fotos:rows});}
 if(action==='curtir'){const me=auth(req,res);if(!me)return;const id=Number(b.id)||0;const exists=await q(`SELECT ${T.pid} FROM ${T.p} WHERE ${T.pid}=?`,[id]);if(!exists.length)return respond(res,{erro:'Publicação inexistente'});const result=await q(`DELETE FROM ${T.likes} WHERE ${T.likeOwner}=? AND ${T.likePost}=?`,[me.id,id]);if(!result.affectedRows)await q(`INSERT INTO ${T.likes} (${T.likeOwner},${T.likePost}) VALUES (?,?)`,[me.id,id]);return respond(res,{ok:true});}
 if(action==='perfil'){const me=auth(req,res,true);if(!me)return;const likes=await q(`SELECT COUNT(*) n FROM ${T.likes} c JOIN ${T.p} p ON p.${T.pid}=c.${T.likePost} WHERE p.${T.owner}=?`,[me.id]);const pubs=await q(`SELECT COUNT(*) n FROM ${T.p} WHERE ${T.owner}=?`,[me.id]);return respond(res,{likes:likes[0].n,publicacoes:pubs[0].n,pubs:pubs[0].n});}
 if(action==='minhas'){const me=auth(req,res,true);if(!me)return;const rows=await q(`SELECT ${T.pid} id,titulo,${T.image} arquivo FROM ${T.p} WHERE ${T.owner}=? ORDER BY ${T.pid} DESC`,[me.id]);return respond(res,{fotos:rows});}
 if(action==='publicar'){const me=auth(req,res,true);if(!me){if(req.file)fs.unlink(req.file.path,()=>{});return;}const title=String(b.titulo||'').trim(),place=String(b.local??b.lugar??'').trim(),file=req.file;const errors={};if(!title)errors.titulo='Informe o título da imagem';if(!place)errors['lugar']='Informe o local onde a foto foi tirada';if(!file)errors['arquivo']='Selecione uma imagem JPG, JPEG, PNG, GIF ou WEBP';if(Object.keys(errors).length){if(file)fs.unlink(file.path,()=>{});return respond(res,{erros:errors});}await q(`INSERT INTO ${T.p} (${T.owner},titulo,${T.place},${T.image}) VALUES (?,?,?,?)`,[me.id,title,place,'uploads/'+file.filename]);return respond(res,{ok:true});}
 if(action==='excluir'){const me=auth(req,res,true);if(!me)return;const id=Number(b.id)||0;const rows=await q(`SELECT ${T.image} arquivo FROM ${T.p} WHERE ${T.pid}=? AND ${T.owner}=?`,[id,me.id]);if(rows.length){await q(`DELETE FROM ${T.p} WHERE ${T.pid}=? AND ${T.owner}=?`,[id,me.id]);const f=rows[0].arquivo;if(f.startsWith('uploads/'))fs.unlink(path.join(uploadDir,path.basename(f)),()=>{});}return respond(res,{ok:true});}
 return res.status(404).json({erro:'Ação desconhecida'});
}
const actions = new Set(['sessao','login','logout','fotos','curtir','perfil','minhas','publicar','excluir']);
app.post('/api/:action', (req,res,next) => {
 const multipart = req.is('multipart/form-data');
 const middleware = multipart ? upload.any() : (a,b,c)=>c();
 middleware(req,res,(err)=>{
  if(err)return res.status(400).json({erro:err.message});
  const action = req.params.action === 'acao' ? req.body?.acao : req.params.action;
  if(!actions.has(action))return res.status(404).json({erro:'Ação desconhecida: '+String(action||'não informada')});
  if(action==='publicar' && req.files?.length)req.file=req.files.find(f=>['arquivo','imagem'].includes(f.fieldname))||req.files[0];
  Promise.resolve(run(action,req,res)).catch(next);
 });
});
app.use(express.static(__dirname,{index:'index.html'}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({erro:'Erro interno. Verifique o MySQL e o terminal.'});});
const port=Number(process.env.PORT||3001);app.listen(port,()=>console.log(`SAEPVision Geovanna: http://localhost:${port} (MySQL: ${DB})`));
