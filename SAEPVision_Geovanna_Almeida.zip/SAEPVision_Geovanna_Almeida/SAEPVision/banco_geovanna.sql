CREATE DATABASE IF NOT EXISTS saepvision_geovanna CHARACTER SET utf8mb4;
USE saepvision_geovanna;

CREATE TABLE usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  handle VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  senha VARCHAR(100) NOT NULL,
  perfil ENUM('comum','fotografo') NOT NULL DEFAULT 'comum',
  avatar VARCHAR(255) NOT NULL DEFAULT 'img/avatar.svg'
);

CREATE TABLE publicacao (
  id_publicacao INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  titulo VARCHAR(100) NOT NULL,
  local_foto VARCHAR(100) NOT NULL,
  arquivo VARCHAR(255) NOT NULL,
  data_post TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

CREATE TABLE curtida (
  id_curtida INT AUTO_INCREMENT PRIMARY KEY,
  id_usuario INT NOT NULL,
  id_publicacao INT NOT NULL,
  UNIQUE KEY uma_por_foto (id_usuario, id_publicacao),
  FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario) ON DELETE CASCADE,
  FOREIGN KEY (id_publicacao) REFERENCES publicacao(id_publicacao) ON DELETE CASCADE
);


-- Dados importados de anexos_prova/arquivo_csv/tb_usuario.csv
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('1', 'fotografo1', 'fotografo_1', 'fotografo1@email.com', '123456', 'fotografo', 'imagens_usuarios/fotografo1.jpg');
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('2', 'fotografo2', 'fotografo_2', 'fotografo2@gmail.com', '123456', 'fotografo', 'imagens_usuarios/fotografo2.jpg');
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('3', 'fotografo3', 'fotografo_3', 'fotografo3@gmail.com', '123456', 'fotografo', 'imagens_usuarios/fotografo3.jpg');
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('4', 'usuario1', 'usuario_1', 'usuario1@gmail.com', '123456', 'comum', 'imagens_usuarios/usuario1.jpg');
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('5', 'usuario2', 'usuario_2', 'usuario2@gmail.com', '123456', 'comum', 'imagens_usuarios/usuario2.jpg');
INSERT INTO usuario (id_usuario, nome, handle, email, senha, perfil, avatar) VALUES ('6', 'usuario3', 'usuario_3', 'usuario3@gmail.com', '123456', 'comum', 'imagens_usuarios/usuario3.jpg');

-- Fotografias iniciais fornecidas no anexo da prova
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('1', 'Foto 1', 'Brasil', 'fotografias/foto1.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('2', 'Foto 2', 'Brasil', 'fotografias/foto2.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('3', 'Foto 3', 'Brasil', 'fotografias/foto3.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('1', 'Foto 4', 'Brasil', 'fotografias/foto4.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('2', 'Foto 5', 'Brasil', 'fotografias/foto5.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('3', 'Foto 6', 'Brasil', 'fotografias/foto6.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('1', 'Foto 7', 'Brasil', 'fotografias/foto7.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('2', 'Foto 8', 'Brasil', 'fotografias/foto8.jpg');
INSERT INTO publicacao (id_usuario, titulo, local_foto, arquivo) VALUES ('3', 'Foto 9', 'Brasil', 'fotografias/foto9.jpg');
